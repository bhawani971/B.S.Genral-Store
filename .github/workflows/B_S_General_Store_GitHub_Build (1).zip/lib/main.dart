
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(SampleShopApp());
}

class SampleShopApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'B.S. General Store',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ProductListScreen(),
    );
  }
}

class Product {
  final String name;
  final String imageUrl;
  final double price;

  Product({required this.name, required this.imageUrl, required this.price});
}

class ProductListScreen extends StatelessWidget {
  final List<Product> products = [
    Product(
        name: 'Product 1',
        imageUrl: 'https://via.placeholder.com/150',
        price: 499.0),
    Product(
        name: 'Product 2',
        imageUrl: 'https://via.placeholder.com/150',
        price: 899.0),
    Product(
        name: 'Product 3',
        imageUrl: 'https://via.placeholder.com/150',
        price: 1299.0),
  ];

  void _openWhatsApp(String phone, String message) async {
    final url = "https://wa.me/$phone?text=${Uri.encodeComponent(message)}";
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('B.S. General Store')),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return Card(
            child: ListTile(
              leading: Image.network(product.imageUrl),
              title: Text(product.name),
              subtitle: Text('₹${product.price.toStringAsFixed(2)}'),
              trailing: ElevatedButton(
                onPressed: () {
                  _openWhatsApp('919065059463',
                      'Hello, I am interested in ${product.name}');
                },
                child: Text('Contact'),
              ),
            ),
          );
        },
      ),
    );
  }
}
